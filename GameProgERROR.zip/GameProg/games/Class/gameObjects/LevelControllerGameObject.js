class LevelControllerGameObject extends GameObject{
    constructor(){
        super("Level")
        this.addComponent(new LevelController())
    }
}
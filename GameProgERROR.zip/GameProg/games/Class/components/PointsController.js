class PointsController extends Component{
    update(){
        this.gameObject.getComponent(TextLabel)
    }
}